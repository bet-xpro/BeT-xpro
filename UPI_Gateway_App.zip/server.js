const express = require('express');
const mysql = require('mysql');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Razorpay = require('razorpay');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'upi_gateway'
});
db.connect(err => {
    if (err) throw err;
    console.log("Database Connected!");
});

const razorpay = new Razorpay({
    key_id: process.env.RAZORPAY_KEY,
    key_secret: process.env.RAZORPAY_SECRET
});

app.post('/register', async (req, res) => {
    const { name, email, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    db.query("INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)",
        [name, email, hashedPassword], (err, result) => {
            if (err) return res.status(500).send("Error Registering");
            res.send("User Registered!");
        });
});

app.post('/login', (req, res) => {
    const { email, password } = req.body;
    db.query("SELECT * FROM users WHERE email = ?", [email], async (err, results) => {
        if (err || results.length === 0) return res.status(401).send("User Not Found!");
        const match = await bcrypt.compare(password, results[0].password_hash);
        if (!match) return res.status(401).send("Invalid Credentials");
        const token = jwt.sign({ id: results[0].id }, process.env.JWT_SECRET, { expiresIn: '1h' });
        res.json({ token });
    });
});

app.post('/create-payment', (req, res) => {
    const { amount, user_id } = req.body;
    const paymentCapture = 1;
    const currency = 'INR';

    const options = {
        amount: amount * 100,
        currency,
        receipt: `txn_${Date.now()}`,
        payment_capture: paymentCapture
    };

    razorpay.orders.create(options, (err, order) => {
        if (err) return res.status(500).send(err);
        db.query("INSERT INTO transactions (user_id, amount, transaction_id) VALUES (?, ?, ?)",
            [user_id, amount, order.id], (dbErr) => {
                if (dbErr) return res.status(500).send("Transaction Error");
                res.json(order);
            });
    });
});

app.post('/verify-payment', (req, res) => {
    const { transaction_id, status } = req.body;
    db.query("UPDATE transactions SET status=? WHERE transaction_id=?", [status, transaction_id], (err) => {
        if (err) return res.status(500).send("Error Updating Payment Status");
        res.send("Payment Verified!");
    });
});

app.listen(5000, () => console.log("Server Running on Port 5000"));