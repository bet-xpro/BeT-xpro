import React, { useState } from 'react';
import axios from 'axios';

const Payment = () => {
    const [amount, setAmount] = useState('');

    const handlePayment = async () => {
        const token = localStorage.getItem('token');
        if (!token) return alert("Login Required");

        const response = await axios.post('http://localhost:5000/create-payment', { amount, user_id: 1 });
        const options = {
            key: "YOUR_RAZORPAY_KEY",
            amount: response.data.amount,
            currency: response.data.currency,
            order_id: response.data.id,
            handler: async function (response) {
                await axios.post('http://localhost:5000/verify-payment', {
                    transaction_id: response.razorpay_order_id,
                    status: "paid"
                });
                alert("Payment Successful");
            }
        };

        const rzp = new window.Razorpay(options);
        rzp.open();
    };

    return (
        <div>
            <h2>Make a Payment</h2>
            <input type="number" placeholder="Enter Amount" onChange={e => setAmount(e.target.value)} />
            <button onClick={handlePayment}>Pay Now</button>
        </div>
    );
};

export default Payment;